<!doctype html>
<html>
<?php 
wp_head();
?>
<div class="wrap">
<input type="button" name="fetch_users" id="user_button" class="button button-primary" value="USER DATA" style="margin-right: 50px;">
<input type="button" name="fetch_articles" id="articles_button" class="button button-primary" value="FETCH ARTICLES">
<br>
<div id='loadingmessage' style='display:none'>
       <h3>Processing....</h3>
</div>
</div>
</html>

