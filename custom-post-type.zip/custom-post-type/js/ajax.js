
jQuery(document).ready(function($){
var ajax_url = plugin_ajax_object.ajax_url;
// For User Data
$("#user_button").click(function(){
//var values = $(this).val();  // if you want the button value
$('#loadingmessage').show();
  var data = {  
    'action': 'userData'      //function call
    //'values' : values      // set the button value
  };

  $.ajax({       // Fetch All records (AJAX request)
    url: ajax_url,
    type: 'POST',
    data: data,
    success: function(response){
      result = JSON.stringify(response.status);
        if (result == 'true') {
        alert("User Successfully Added");
        $('#loadingmessage').hide();
        }
        else
        {
           alert("User Not Added"); 
           $('#loadingmessage').hide();      
        } 
          
      } 
    });
}); 

// For Articles Data
$("#articles_button").click(function(){
  //var articles_values = $(this).val();   //if you want the button value 
  $('#loadingmessage').show(); 
  var data = {
    'action': 'articlesData'          // function call 
    //'values' : articles_values     // set the button value
  };

  $.ajax({      //Fetch All records (AJAX request)
    url: ajax_url,
    type: 'POST',
    data: data,
    success: function(response){
      result = JSON.stringify(response.status);
       if (result == 'true') {
        alert("Articles Successfully Added");
        $('#loadingmessage').hide();
        }
        else 
        {
           alert("Articles Not Added");
           $('#loadingmessage').hide();       
        } 
          
      } 
     });
   }); 
});


