<?php
/*
Plugin Name: Custom Post Type
Plugin URI: 
description: Plugin for Self Purpose Only
Version: 1.1
Author: Farooque 
Author URI: ###
*/

add_action( 'init', 'articles_posttype' ); // registerd the articles post type 

function articles_posttype() {
   add_theme_support( 'post-thumbnails' );

    register_post_type( 'articles',
        array(
            'labels' => array(
                'name' => __( 'Articles' ),
                'singular_name' => __( 'Articles' ),
                'menu_name' => __( 'Articles' ),
                'all_items' => __( 'All Articles' ),
                'add_new' => __( 'Add New' ),
                'add_new_item' => __( 'Add New Articles' ),
                'edit' => __( 'Edit' ),
                'edit_item' => __( 'Edit Articles' ),
                'new_item' => __( 'New Articles' ),
                'view' => __( 'View' ),
                'view_item' => __( 'View Articles' ),
                'search_items' => __( 'Search Articles' ),
                'not_found' => __( 'No Articles Founder' ),
                'not_found_in_trash' => __( 'No Articles Found in Trash' ),
                'parent' => __( 'Parent Articles' ),

            ),
            'public' => true,
            'description' => "",
            'show_ui' => true,
            'show_in_rest' => true,
            'has_archive' => true,
            'show_in_menu' => true,
            'exclude_from_search' => false,
            "capability_type" => 'post',
            'map_meta_cap' => true,
            'hierarchical' => true,
            'rewrite' => array('slug' => 'articles'),
            'query_var' => true,
            'menu_icon' => plugins_url('article-icon.png',  __FILE__),
            'supports' => array( "title", "author", "thumbnail", "excerpt","editor")
            
        )

    );
}

// sub menu action call
add_action( 'admin_menu', 'users_articles_data' );
if ( ! function_exists( 'users_articles_data' ) ) {
    function users_articles_data() {
        add_submenu_page(
            'edit.php?post_type=articles', 
            'Users & Articles Data', // page title
            'Users & Articles',      //menu title
            'manage_options',        //roles and capabiliyt
            'users_articles_page',   //menu slug
            'user_articles_callback' //call back function
        );
    }
} 

/* Display callback for the submenu page */
function user_articles_callback() { 
     include "user-article-page.php";
}

// calling js and ajax admin file by using wp_plugin_scripts function
function wp_plugin_scripts() {
        wp_enqueue_script( 'script-js', plugins_url( '/js/ajax.js', __FILE__ ),array('jquery'));
        wp_localize_script( 'script-js', 'plugin_ajax_object',array( 'ajax_url' => admin_url( 'admin-ajax.php' ) ) );
}
add_action('wp_enqueue_scripts', 'wp_plugin_scripts');

/* Ajax function call to fetch the user API data and insert into WP users  */
add_action( 'wp_ajax_userData', 'userData_callback');   // action hook for 
add_action("wp_ajax_nopriv_userData", "userData_callback");  // action hook for


function userData_callback()      
{
        $ch = curl_init( );     //Curl call to fetching the data through the API call
        curl_setopt($ch, CURLOPT_URL, "http://jsonplaceholder.typicode.com/users");    // url call 
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        $result = curl_exec($ch);      // curl execution
        curl_close($ch);    // curl close 
        $response = json_decode($result);

        // responce decoded on json format  
        if(!empty($response)) {
        foreach ($response as $row) {    
                global $wpdb;    // global variable call and insert the user data through the wp_insert_user func.
                $userdata = array(                    
                    'user_login' =>  $row->username,
                    'user_url'   =>  $row->website,
                    'display_name' => $row->name,
                    'user_pass'  =>  $row->username, 
                    'role' => 'author',
                    'user_email'  => $row->email,
                );

                $user_id = wp_insert_user( $userdata ) ;   
                add_user_meta( $user_id, 'street', $row->address->street, true );   // inserting the extra field's info.
                add_user_meta( $user_id, 'suite', $row->address->suite, true );
                add_user_meta( $user_id, 'city', $row->address->city, true );
                add_user_meta( $user_id, 'pincode', $row->address->zipcode, true );
                add_user_meta( $user_id, 'phone', $row->phone, true );
                add_user_meta( $user_id, 'companyname', $row->company->name, true );
                add_user_meta( $user_id, 'website', $row->website, true );
                }
        return wp_send_json(['status'=>true]);       
        }
        else { return wp_send_json(['status'=>false]); } 
}

/* Artcles section */
/* Ajax function call to fetch the posts through the API and insert into Articles Post-type  */
add_action( 'wp_ajax_articlesData', 'articlesData_callback');   // action hook for
add_action("wp_ajax_nopriv_articlesData", "articlesData_callback");  // action hook for

function articlesData_callback()
{       
    $ch = curl_init( );    //Curl call to fetching the data through the API call
    curl_setopt($ch, CURLOPT_URL, "https://jsonplaceholder.typicode.com/posts");   // url call
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    $articles_result = curl_exec($ch);    // curl execution
    curl_close($ch);                      // curl close  
    $articles_response = json_decode($articles_result);   //responce decoded on json format  
    
       if(!empty($articles_response)) {
            $i = 1;                    // counter set for limited post to insert please commnet the line if you don't want.
            foreach ($articles_response as $articles_row) {
                    if ($i++ == 10) break;       //counter break 
                        global $wpdb;                // global variable call 
                        $author = get_user_by('email', 'Sincere@april.biz');  // API responce and there into the user table.
                        $author_id = $author->ID;
                        if(empty($author_id)) {                        // if API user are not there so picking the current user  
                            $author_id = get_current_user_id();                    
                        }
                            //if(post_exists($title) === 0){ un comment for avoid duplication
                        $articlesData = wp_insert_post(array(                   
                                'post_title'    => $articles_row->title, 
                                'post_content'  => $articles_row->body,
                                'post_type'     => 'articles',
                                'post_status'   => 'publish',
                                'post_author'   => $author_id
                        ));
                            wp_insert_post( $articlesData );
                            wp_reset_postdata(); 
                            //}
                    }
                     return wp_send_json(['status'=>true]);
        }
}

// add the extra fields user section
add_action( 'show_user_profile', 'extra_user_profile_fields' );
add_action( 'edit_user_profile', 'extra_user_profile_fields' );

function extra_user_profile_fields( $user ) { ?>
    
    <h3><?php _e("Extra Fields", "blank"); ?></h3>

    <table class="form-table">
    <h3>Address</h3>
    <tr>
        <th><label for="street"><?php _e("Street"); ?></label></th>
        <td>
            <input type="text" name="street" id="street" value="<?php echo esc_attr( get_the_author_meta( 'street', $user->ID ) ); ?>" class="regular-text" /><br />
        </td>
    </tr>
    <tr>
        <th><label for="suite"><?php _e("Suite"); ?></label></th>
        <td>
            <input type="text" name="suite" id="suite" value="<?php echo esc_attr( get_the_author_meta( 'suite', $user->ID ) ); ?>" class="regular-text" /><br />
        </td>
    </tr>
    <tr>
        <th><label for="city"><?php _e("City"); ?></label></th>
        <td>
            <input type="text" name="city" id="city" value="<?php echo esc_attr( get_the_author_meta( 'city', $user->ID ) ); ?>" class="regular-text" /><br />
        </td>
    </tr>
    <tr>
    <th><label for="pincode"><?php _e("Pin Code"); ?></label></th>
        <td>
            <input type="text" name="pincode" id="pincode" value="<?php echo esc_attr( get_the_author_meta( 'pincode', $user->ID ) ); ?>" class="regular-text" /><br />
        </td>
    </tr>
    <tr>
    <th><label for="phone"><?php _e("Phone"); ?></label></th>
        <td>
            <input type="text" name="phone" id="phone" value="<?php echo esc_attr( get_the_author_meta( 'phone', $user->ID ) ); ?>" class="regular-text" /><br />
        </td>
    </tr>
    <tr>
    <th><label for="companyname"><?php _e("Company Name"); ?></label></th>
        <td>
            <input type="text" name="companyname" id="companyname" value="<?php echo esc_attr( get_the_author_meta( 'companyname', $user->ID ) ); ?>" class="regular-text" /><br />
        </td>
    </tr>
    <tr>
    <th><label for="website"><?php _e("Website"); ?></label></th>
        <td>
            <input type="text" name="website" id="website" value="<?php echo esc_attr( get_the_author_meta( 'website', $user->ID ) ); ?>" class="regular-text" />
        </td>
    </tr>
</table>
<?php }

// Add action hook for saving the extra fields data  
add_action( 'personal_options_update', 'save_extra_user_profile_fields' );
add_action( 'edit_user_profile_update', 'save_extra_user_profile_fields' );

function save_extra_user_profile_fields( $user_id ) {  //nonce using for a safe post data
    if ( empty( $_POST['_wpnonce'] ) || ! wp_verify_nonce( $_POST['_wpnonce'], 'update-user_' . $user_id ) ) {  
        return;
    }
    
    if ( !current_user_can( 'edit_user', $user_id ) ) { 
        return false; 
    }
    update_user_meta( $user_id, 'street', $_POST['street'] );   // update user meta field based on user ID.
    update_user_meta( $user_id, 'suite', $_POST['suite'] );
    update_user_meta( $user_id, 'city', $_POST['city'] );
    update_user_meta( $user_id, 'pincode', $_POST['pincode'] );
    update_user_meta( $user_id, 'phone', $_POST['phone'] );
    update_user_meta( $user_id, 'companyname', $_POST['companyname'] );
    update_user_meta( $user_id, 'website', $_POST['website'] );
}
?>